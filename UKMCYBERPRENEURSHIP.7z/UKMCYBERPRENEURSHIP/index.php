<!DOCTYPE html>
<html>
<head>
  <title>Cyber Preneurship</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- ######################## BOOSTRAP ######################## -->
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
  <!-- ######################## BOOSTRAP ######################## -->

  <!-- ######################## JAVA SCRIPT ######################## -->
  <script type="text/javascript" src="assets/js/jquery.min.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
  <!-- ######################## JAVA SCRIPT ######################## -->

  <!-- ################################ BODY ########################### -->
  <link rel="stylesheet" type="text/css" href="css/body.css">
  <link rel="stylesheet" type="text/css" href="css/home1.css">
  <link rel="stylesheet" type="text/css" href="css/about.css">
  <link rel="stylesheet" type="text/css" href="css/visi.css">
  <!-- ################################ BODY ########################### -->

</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<!-- buka navbar name -->
  <nav class="navbar navbar-inverse navbar navbar-static-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span> 
        </button>
        <a class="nav navbar-brand" href="?page=Home">
          <!-- <span class="glyphicon glyphicon-home" title="Home"></span> -->
          CyberPreneurship
        </a>
    </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#about">About</a></li>
            <li><a href="#visi">Visi & Misi</a></li>
            <li><a href="#tujuan">Tujuan</a></li>
          </ul>
        </div>
    </div>
  </nav>
<!-- tutup navbar name -->

<!-- ########################### HOME1 ############################## -->
<div class="bghome1 container-fluid text-center">

</div>
<!-- ########################### HOME1 ############################## -->

<br>

    <!-- ########################### GAMABR ABOUT ############################## -->
    <div class="gambarabout container">
    </div>
    <!-- ########################### GAMABR ABOUT ############################## -->

<br>

<!-- ########################### ABOUT ############################## -->
<div class="bgabout container-fluid text-center">
  <h2>Isi About CyberPreneurship</h2>
</div>
<!-- ########################### ABOUT ############################## -->
<br>
<!-- ########################### VISI ############################## -->
<div class="bgvisi container-fluid text-center">
  <h2>Isi Visi & Misi</h2>
</div>
<!-- ########################### VISI ############################## -->

</body>
</html>

<!-- script fouter -->
<script>
  $(document).ready(function(){
      // Initialize Tooltip
      $('[data-toggle="tooltip"]').tooltip(); 
  })
</script>
<!-- tutup script -->

<!-- script tool up -->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a,  footer a[href='#myPage']").on('click', function(event) {

  // Make sure this.hash has a value before overriding default behavior
  if (this.hash !== "") {

    // Prevent default anchor click behavior
    event.preventDefault();

    // Store hash
    var hash = this.hash;

    // Using jQuery's animate() method to add smooth page scroll
    // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
    $('html, body').animate({
      scrollTop: $(hash).offset().top
    }, 900, function(){

      // Add hash (#) to URL when done scrolling (default click behavior)
      window.location.hash = hash;
      });
    } // End if 
  });
})
</script>
<!-- tutup -->